<?php
/**
 * Template part for displaying contact from submit button
 */
?>
<button type="submit" class="tm_pb_contact_submit tm_pb_button<?php echo $this->_var( 'icon_class' ); ?>"<?php echo $this->_var( 'icon' ); ?>><?php
	echo $this->_var( 'submit_text' );
?></button>